﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linq.Exercice02
{
    public enum ColorType
    {
        Red,
        Yellow,
        Blue,
        Black,
        Gray,
        White
    }
}
