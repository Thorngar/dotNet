﻿using System;

namespace Linq.Exercice02
{

    using System.Collections.Generic;
    using System.Linq;

    class Program
    {
        static void DisplayInConsole(IEnumerable<Car> cars)
        {
            foreach(var car in cars)
            {
                Console.WriteLine($"{car.Id} - {car.Color} - {car.CreationDate} - {car.Manufacturer} - {car.Speed}");
            }

            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            var cars = CarMockup.GetAll();

            // récupération des voitures rouge

            var a = cars.Where(cars => cars.Color == ColorType.Red);

            DisplayInConsole(a);

            // récupération des voitures rouges ou jaune

            var b = cars.Where(cars => cars.Color == ColorType.Red || cars.Color == ColorType.Yellow);

            DisplayInConsole(b);

            // tri des différentes voitures selon leur ID de manière croissante

            var c = cars.OrderBy(cars => cars.Id);

            DisplayInConsole(c);

            // tri des différentes voitures selon leur puissance de manière décroissante ainsi que sur leur marque

            var d = cars.OrderByDescending(cars => cars.Speed).ThenByDescending(cars => cars.Manufacturer);

            DisplayInConsole(d);

            // récupération des voitures ayant une couleur Jaune ainsi qu'une vitesse supérieur à 150

            var e = cars.Where(cars => cars.Color == ColorType.Yellow && cars.Speed > 150);

            DisplayInConsole(e);

            // récupération de la dernière voiture ayant la couleur rouge


            // récupération de la puissance moyenne de toutes les voitures


            // récupération de la puissance de la voiture ayant une couleur Bleu ainsi que la marque "Megane"


            // récupération des informations suivantes : Id, Couleur en string, Puissance dans un tableau


            // y a-t-il au moins une voiture ayant une couleur Grise ?


            // toutes les voitures sont-elles Blanche ?


            // récupération des voitures ayant moins de 5 ans


            // récupération de toutes les voitures sous la forme d'un tableau

            Console.ReadLine();
        }
    }
}
